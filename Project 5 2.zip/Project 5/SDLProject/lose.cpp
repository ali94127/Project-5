//
//  mainmenu.cpp
//  SDLProject
//
//  Created by ali on 4/19/20.
//  Copyright © 2020 ctg. All rights reserved.
//

#include "lose.h"

#define LOSE_WIDTH 1
#define LOSE_HEIGHT 1

unsigned int lose_data[] =
{
 0
};

void Lose::Initialize() {
    
    state.nextScene = -1;
    GLuint mapTextureID = Util::LoadTexture("tileset.png");
    state.map = new Map(LOSE_WIDTH, LOSE_HEIGHT, lose_data, mapTextureID, 1.0f, 4, 1);
    state.player = new Entity();
    state.player->entityType = PLAYER;
    
}
void Lose::Update(float deltaTime) {
    
    
}
void Lose::Render(ShaderProgram *program) {
    state.map->Render(program);
    Util::DrawText(program, Util::LoadTexture("font1.png"), "YOU LOSE!", 0.5f, -0.25f, glm::vec3(3.5, -3, 0));
}
